﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WeightForWorld.Controllers
{
    public class W4WProgramController : Controller
    {
        // GET: W4WProgram
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Why()
        {
            return View();
        }
        public ActionResult How()
        {
            return View();
        }

        public ActionResult AboutW4W()
        {
            return View();
        }
    }
}