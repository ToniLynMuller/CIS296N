﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WeightForWorld.Models;

namespace WeightForWorld.Controllers
{
    public class WeeklyWeighsController : Controller
    {
        private WeightForWorldContext db = new WeightForWorldContext();

        // GET: WeeklyWeighs
        public ActionResult Index()
        {
            return View(db.WeeklyWeighs.ToList());
        }

        // GET: WeeklyWeighs/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            WeeklyWeigh weeklyWeigh = db.WeeklyWeighs.Find(id);
            if (weeklyWeigh == null)
            {
                return HttpNotFound();
            }
            return View(weeklyWeigh);
        }

        // GET: WeeklyWeighs/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: WeeklyWeighs/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "WeeklyWeighID,MemberID,WeighDate,Weight")] WeeklyWeigh weeklyWeigh)
        {
            if (ModelState.IsValid)
            {
                db.WeeklyWeighs.Add(weeklyWeigh);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(weeklyWeigh);
        }

        // GET: WeeklyWeighs/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            WeeklyWeigh weeklyWeigh = db.WeeklyWeighs.Find(id);
            if (weeklyWeigh == null)
            {
                return HttpNotFound();
            }
            return View(weeklyWeigh);
        }

        // POST: WeeklyWeighs/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "WeeklyWeighID,MemberID,WeighDate,Weight")] WeeklyWeigh weeklyWeigh)
        {
            if (ModelState.IsValid)
            {
                db.Entry(weeklyWeigh).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(weeklyWeigh);
        }

        // GET: WeeklyWeighs/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            WeeklyWeigh weeklyWeigh = db.WeeklyWeighs.Find(id);
            if (weeklyWeigh == null)
            {
                return HttpNotFound();
            }
            return View(weeklyWeigh);
        }

        // POST: WeeklyWeighs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            WeeklyWeigh weeklyWeigh = db.WeeklyWeighs.Find(id);
            db.WeeklyWeighs.Remove(weeklyWeigh);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
