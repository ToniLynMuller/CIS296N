﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WeightForWorld.Controllers
{
    public class SponsorController : Controller
    {
        // GET: Sponsor
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult SponsorResponsibilities()
        {
            return View();
        }
    }
}