﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WeightForWorld.Controllers
{
    public class CharityController : Controller
    {
        // GET: Charity
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult NonSectarian()
        {
            return View();
        }

        public ActionResult FaithBased()
        {
            return View();
        }
    }
}