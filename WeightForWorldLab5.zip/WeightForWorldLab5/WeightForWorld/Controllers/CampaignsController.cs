﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WeightForWorld.Models;

namespace WeightForWorld.Controllers
{
    public class CampaignsController : Controller
    {
        private WeightForWorldContext db = new WeightForWorldContext();

        // GET: Campaigns
        public ActionResult Index()
        {

            return View(GetCampaigns());
        }

        // GET: Campaigns/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CampaignViewModel campVM = GetSingleCampaign(id);
            if (campVM == null)
            {
                return HttpNotFound();
            }
            return View(campVM);
        }

        // GET: Campaigns/Create
        public ActionResult Create()
        {
            ViewBag.MemFirst = new SelectList(db.Members.OrderBy(m => m.FirstName), "MemberID", "FirstName");
            ViewBag.CharityNames = new SelectList(db.Charities.OrderBy(c => c.CharityName), "CharityID", "CharityName");
            return View();
        }

        // POST: Campaigns/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "CampaignID,MemberItem,StartDate,EndDate,Goal,CharityItem,PhysApproveDate,MemFirst,CharityNames")] CampaignViewModel campVM, int memFirst, int charNames)
        {
            if (ModelState.IsValid)
            {
                Member mem = (from m in db.Members
                              where m.MemberID == memFirst
                              select m).FirstOrDefault();

                Charity charity = (from c in db.Charities
                                   where c.CharityID == charNames
                                   select c).FirstOrDefault();
                Campaign campaign = new Campaign
                {
                    MemberID = mem.MemberID,
                    StartDate = campVM.StartDate,
                    EndDate = campVM.EndDate,
                    Goal = campVM.Goal,
                    CharityID = charity.CharityID,
                    PhysApproveDate = campVM.PhysApproveDate
                };

                db.Campaigns.Add(campaign);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(campVM);
        }

        // GET: Campaigns/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CampaignViewModel campaign = GetSingleCampaign(id);
            if (campaign == null)
            {
                return HttpNotFound();
            }
            ViewBag.MemFirst = new SelectList(db.Members.OrderBy(m => m.FirstName), "MemberID", "FirstName", campaign.MemberItem.MemberID);
            ViewBag.CharityNames = new SelectList(db.Charities.OrderBy(c => c.CharityName), "CharityID", "CharityName", campaign.CharityItem.CharityID);
            return View(campaign);
        }

        // POST: Campaigns/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "CampaignID,MemberItem,StartDate,EndDate,Goal,CharityItem,PhysApproveDate,MemFirst,CharityNames")] CampaignViewModel campVM, int memFirst, int charityNames)
        {
            if (ModelState.IsValid)
            {
                //get existing campaign
                Campaign campaign = (from c in db.Campaigns
                                     where c.CampaignID == campVM.CampaignID
                                     select c).FirstOrDefault();
                
                //set values                
                campaign.MemberID = memFirst;
                campaign.StartDate = campVM.StartDate;
                campaign.EndDate = campVM.EndDate;
                campaign.Goal = campVM.Goal;
                campaign.CharityID = charityNames;
                campaign.PhysApproveDate = campVM.PhysApproveDate;

                db.Entry(campaign).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(campVM);
        }

        // GET: Campaigns/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CampaignViewModel campVM = GetSingleCampaign(id);
            if (campVM == null)
            {
                return HttpNotFound();
            }
            return View(campVM);
        }

        // POST: Campaigns/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Campaign campaign = db.Campaigns.Find(id);
            db.Campaigns.Remove(campaign);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private List<CampaignViewModel> GetCampaigns()
        {
            List<CampaignViewModel> campVMs = new List<CampaignViewModel>();
            campVMs = (from camp in db.Campaigns
                       join mem in db.Members on camp.MemberID equals mem.MemberID
                       join charity in db.Charities on camp.CharityID equals charity.CharityID
                       select new CampaignViewModel
                       {
                           CampaignID = camp.CampaignID,
                           MemberItem = mem,
                           StartDate = camp.StartDate,
                           EndDate = camp.EndDate,
                           Goal = camp.Goal,
                           CharityItem = charity,
                           PhysApproveDate = camp.PhysApproveDate
                       }).ToList();
            return campVMs;
        }
        private CampaignViewModel GetSingleCampaign(int? campID)
        {
            CampaignViewModel campVM = (from camp in db.Campaigns
                       join mem in db.Members on camp.MemberID equals mem.MemberID
                       join charity in db.Charities on camp.CharityID equals charity.CharityID
                       where camp.CampaignID == campID
                       select new CampaignViewModel
                       {
                           CampaignID = camp.CampaignID,
                           MemberItem = mem,
                           StartDate = camp.StartDate,
                           EndDate = camp.EndDate,
                           Goal = camp.Goal,
                           CharityItem = charity,
                           PhysApproveDate = camp.PhysApproveDate
                       }).FirstOrDefault();
            return campVM;
        }
    }
}
