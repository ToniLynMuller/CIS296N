﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WeightForWorld.Models;

namespace WeightForWorld.Controllers
{
    public class ManagerWeeklyWeighsController : Controller
    {
        private WeightForWorldContext db = new WeightForWorldContext();

        // GET: ManagerWeeklyWeighs
        public ActionResult Index()
        {
            return View(GetWeighs());
        }

        // GET: ManagerWeeklyWeighs/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            WeeklyWeighsViewModel weighsVM = GetSingleWeigh(id);
            if (weighsVM == null)
            {
                return HttpNotFound();
            }
            return View(weighsVM);
        }

        // GET: ManagerWeeklyWeighs/Create
        public ActionResult Create()
        {
            ViewBag.MemFirst = new SelectList(db.Members.OrderBy(m => m.FirstName), "MemberID", "FirstName");
            return View();
        }

        // POST: ManagerWeeklyWeighs/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "WeeklyWeighID,MemberItem,WeighDate,Weight,MemFirst")] WeeklyWeighsViewModel weighVM, int memFirst)
        {
            if (ModelState.IsValid)
            {
                Member member = (from m in db.Members
                                 where m.MemberID == memFirst
                                 select m).FirstOrDefault();
                WeeklyWeigh weigh = new WeeklyWeigh()
                {
                    MemberID = member.MemberID,
                    WeighDate = weighVM.WeighDate,
                    Weight = weighVM.Weight
                };

                db.WeeklyWeighs.Add(weigh);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(weighVM);
        }

        // GET: ManagerWeeklyWeighs/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            WeeklyWeighsViewModel weighVM = GetSingleWeigh(id);
            if (weighVM == null)
            {
                return HttpNotFound();
            }
            ViewBag.MemFirst = new SelectList(db.Members.OrderBy(m => m.FirstName), "MemberID", "FirstName", weighVM.MemberItem.MemberID);
            return View(weighVM);
        }

        // POST: ManagerWeeklyWeighs/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "WeeklyWeighID,MemberItem,WeighDate,Weight, MemFirst")] WeeklyWeighsViewModel weighVM, int memFirst)
        {
            if (ModelState.IsValid)
            {
                WeeklyWeigh weigh = (from w in db.WeeklyWeighs
                                     where w.WeeklyWeighID == weighVM.WeeklyWeighID
                                     select w).FirstOrDefault();

                weigh.MemberID = memFirst;
                weigh.WeighDate = weighVM.WeighDate;
                weigh.Weight = weighVM.Weight;

                db.Entry(weigh).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(weighVM);
        }

        // GET: ManagerWeeklyWeighs/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            WeeklyWeighsViewModel weighVM = GetSingleWeigh(id);
            if (weighVM == null)
            {
                return HttpNotFound();
            }
            return View(weighVM);
        }

        // POST: ManagerWeeklyWeighs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            WeeklyWeigh weeklyWeigh = db.WeeklyWeighs.Find(id);
            db.WeeklyWeighs.Remove(weeklyWeigh);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
        private List<WeeklyWeighsViewModel> GetWeighs()
        {
            List<WeeklyWeighsViewModel> weighsVMs = new List<WeeklyWeighsViewModel>();
            weighsVMs = (from weigh in db.WeeklyWeighs
                       join mem in db.Members on weigh.MemberID equals mem.MemberID
                         select new WeeklyWeighsViewModel
                       {
                           WeeklyWeighID = weigh.WeeklyWeighID,
                           MemberItem = mem,
                           WeighDate = weigh.WeighDate,
                           Weight = weigh.Weight
                       }).ToList();
            return weighsVMs;
        }
        private WeeklyWeighsViewModel GetSingleWeigh(int? weighID)
        {
            WeeklyWeighsViewModel weighsVM = (from weigh in db.WeeklyWeighs
                                                    join mem in db.Members on weigh.MemberID equals mem.MemberID
                                                    where weigh.WeeklyWeighID == weighID
                                                    select new WeeklyWeighsViewModel
                                                    {
                                                        WeeklyWeighID = weigh.WeeklyWeighID,
                                                        MemberItem = mem,
                                                        WeighDate = weigh.WeighDate,
                                                        Weight = weigh.Weight
                                                    }).FirstOrDefault();
            return weighsVM;
        }

    }
}
