﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WeightForWorld.Models
{
    public class Charity
    {
        public int CharityID { get; set; }
        public string CharityName { get; set; }
        public string CharityContact { get; set; }
        public string Street1 { get; set; }
        public string Street2 { get; set; }
        public string City { get; set; }
        public string StateID { get; set; }
        public string Country { get; set; }
        public string Zip { get; set; }
        public string CharityPhone { get; set; }
        public string CharityEmail { get; set; }
        public string Website { get; set; }
        public bool FaithBased { get; set; }

    }
}