﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WeightForWorld.Models
{
    public class Campaign
    {
        public int CampaignID { get; set; }
        public int MemberID { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int Goal { get; set; }
        public int CharityID { get; set; }
        public DateTime PhysApproveDate { get; set; }
    }
}