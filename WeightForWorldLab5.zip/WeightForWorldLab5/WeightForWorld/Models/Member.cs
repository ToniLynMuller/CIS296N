﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WeightForWorld.Models
{
    public class Member
    {
        List<WeeklyWeigh> weeklyWeighs = new List<WeeklyWeigh>();
        public int MemberID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string LoginName { get; set; }
        public string Password { get; set; }
        public string Street1 { get; set; }
        public string Street2 { get; set; }
        public string City { get; set; }
        public string StateID { get; set; }
        public string Country { get; set; }
        public string Zip { get; set; }        
        public string Email { get; set; }
        public string Phone { get; set; }
        public List<WeeklyWeigh> WeeklyWeighs
        {
            get { return weeklyWeighs; }
        }
    }
}