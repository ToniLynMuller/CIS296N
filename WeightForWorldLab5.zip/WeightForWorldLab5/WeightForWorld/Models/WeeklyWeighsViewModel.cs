﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WeightForWorld.Models
{
    public class WeeklyWeighsViewModel
    {
        Member member = new Member();
        public int WeeklyWeighID { get; set; }
        public Member MemberItem { get { return member; } set { member = value; } }
        public DateTime WeighDate { get; set; }
        public double Weight { get; set; }
    }
}