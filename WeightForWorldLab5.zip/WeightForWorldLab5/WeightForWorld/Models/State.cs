﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WeightForWorld.Models
{
    public class State
    {
        public string StateID { get; set; }
        public string StateName { get; set; }
    }
}