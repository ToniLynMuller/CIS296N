﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WeightForWorld.Models
{
    public class WeeklyWeigh
    {
        public int WeeklyWeighID { get; set; }
        public int MemberID { get; set; }
        public DateTime WeighDate { get; set; }
        public double Weight { get; set; }
    }
}