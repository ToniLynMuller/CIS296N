﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WeightForWorld.Models
{
    public class CampaignViewModel
    {
        Member member = new Member();
        Charity charity = new Charity();
        public int CampaignID { get; set; }
        public Member MemberItem { get { return member; } set { member = value; } }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int Goal { get; set; }
        public Charity CharityItem { get { return charity; } set { charity = value; } }
        public DateTime PhysApproveDate { get; set; }

    }
}