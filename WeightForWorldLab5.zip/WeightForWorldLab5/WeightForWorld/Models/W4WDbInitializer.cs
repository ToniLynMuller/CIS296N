﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace WeightForWorld.Models
{
    public class W4WDbInitializer : DropCreateDatabaseIfModelChanges<WeightForWorldContext>
    {
        protected override void Seed(WeightForWorldContext context)
        {
            //Create States
            State oregon = new State { StateID = "OR", StateName = "Oregon" };
            State colorado = new State { StateID = "CO", StateName = "Colorado" };
            State dc = new State { StateID = "DC", StateName = "District of Columbia" };
            State bc = new State {StateID = "BC", StateName="British Columbia"};
            context.States.Add(oregon);
            context.States.Add(colorado);
            context.States.Add(dc);
            context.States.Add(bc);
            
            //Create Members
            Member member1 = new Member {
                FirstName="Bill", 
                LastName="Bailey", 
                LoginName="BigBill", 
                Password="BB8", 
                Street1 = "123 Main Street", 
                City = "Vancouver", 
                StateID = "BC", 
                Country = "Canada", 
                Zip = "V5X 2G2",             
                Email="BigBill@gmail.com",
                Phone="541-123-3333"
            };
            Member member2 = new Member
            {
                FirstName = "Mary",
                LastName = "Mason",
                LoginName = "MaryRuns",
                Password = "MarathonGirl",
                Street1 = "456 Oak Avenue", 
                City = "Springfield", 
                StateID = "OR", 
                Country = "USA", 
                Zip = "97477",            
                Email = "Mary26@gmail.com",
                Phone = "541-456-6666"
            };
            Member member3 = new Member
            {
                FirstName = "Sandra",
                LastName = "Smith",
                LoginName = "SandySmith",
                Password = "SandySmiles",
                Street1 = "789 Coburg Rd.", 
                City = "Coburg", 
                StateID = "OR", 
                Country = "USA",
                Zip = "97408",           
                Email = "SandyS@gmail.com",
                Phone = "541-789-9999"
            };

            //Create WeeklyWeighs
            WeeklyWeigh mem1ww1 = new WeeklyWeigh { MemberID = 1, WeighDate = new DateTime(2016, 1, 1, 0, 0, 0), Weight = 300 };
            WeeklyWeigh mem1ww2 = new WeeklyWeigh { MemberID = 1, WeighDate = new DateTime(2016, 1, 8, 0, 0, 0), Weight = 295 };
            WeeklyWeigh mem1ww3 = new WeeklyWeigh { MemberID = 1, WeighDate = new DateTime(2016, 1, 15, 0, 0, 0), Weight = 291 };
            WeeklyWeigh mem1ww4 = new WeeklyWeigh { MemberID = 1, WeighDate = new DateTime(2016, 1, 22, 0, 0, 0), Weight = 289 };

            member1.WeeklyWeighs.Add(mem1ww1);
            member1.WeeklyWeighs.Add(mem1ww2);
            member1.WeeklyWeighs.Add(mem1ww3);
            member1.WeeklyWeighs.Add(mem1ww4);

            WeeklyWeigh mem2ww1 = new WeeklyWeigh { MemberID = 2, WeighDate = new DateTime(2016, 1, 1, 0, 0, 0), Weight = 150 };
            WeeklyWeigh mem2ww2 = new WeeklyWeigh { MemberID = 2, WeighDate = new DateTime(2016, 1, 8, 0, 0, 0), Weight = 147 };
            WeeklyWeigh mem2ww3 = new WeeklyWeigh { MemberID = 2, WeighDate = new DateTime(2016, 1, 15, 0, 0, 0), Weight = 145 };
            WeeklyWeigh mem2ww4 = new WeeklyWeigh { MemberID = 2, WeighDate = new DateTime(2016, 1, 22, 0, 0, 0), Weight = 142 };

            member2.WeeklyWeighs.Add(mem2ww1);
            member2.WeeklyWeighs.Add(mem2ww2);
            member2.WeeklyWeighs.Add(mem2ww3);
            member2.WeeklyWeighs.Add(mem2ww4);

            WeeklyWeigh mem3ww1 = new WeeklyWeigh { MemberID = 3, WeighDate = new DateTime(2016, 1, 1, 0, 0, 0), Weight = 210 };
            WeeklyWeigh mem3ww2 = new WeeklyWeigh { MemberID = 3, WeighDate = new DateTime(2016, 1, 8, 0, 0, 0), Weight = 204 };
            WeeklyWeigh mem3ww3 = new WeeklyWeigh { MemberID = 3, WeighDate = new DateTime(2016, 1, 15, 0, 0, 0), Weight = 199 };
            WeeklyWeigh mem3ww4 = new WeeklyWeigh { MemberID = 3, WeighDate = new DateTime(2016, 1, 22, 0, 0, 0), Weight = 197 };

            member3.WeeklyWeighs.Add(mem3ww1);
            member3.WeeklyWeighs.Add(mem3ww2);
            member3.WeeklyWeighs.Add(mem3ww3);
            member3.WeeklyWeighs.Add(mem3ww4);

            context.Members.Add(member1);
            context.Members.Add(member2);
            context.Members.Add(member3);
            
            //Create Campaigns
            Campaign mem1camp1 = new Campaign
            {
                MemberID = 1,
                StartDate = new DateTime(2016, 1, 1, 0, 0, 0),
                EndDate = new DateTime(2016, 3, 31, 0, 0, 0),
                Goal = 25,
                CharityID = 1,
                PhysApproveDate = new DateTime(2015, 12, 15, 0, 0, 0)
            };

            Campaign mem2camp1 = new Campaign
            {
                MemberID = 2,
                StartDate = new DateTime(2016, 1, 1, 0, 0, 0),
                EndDate = new DateTime(2016, 2, 28, 0, 0, 0),
                Goal = 20,
                CharityID = 2,
                PhysApproveDate = new DateTime(2015, 12, 28, 0, 0, 0)
            };

            Campaign mem3camp1 = new Campaign
            {
                MemberID = 3,
                StartDate = new DateTime(2016, 1, 1, 0, 0, 0),
                EndDate = new DateTime(2016, 6, 30, 0, 0, 0),
                Goal = 45,
                CharityID = 2,
                PhysApproveDate = new DateTime(2015, 12, 22, 0, 0, 0)
            };

            context.Campaigns.Add(mem1camp1);
            context.Campaigns.Add(mem2camp1);
            context.Campaigns.Add(mem3camp1);

            //Create Charities            
            Charity compassion = new Charity
            {
                CharityName = "Compassion International",
                CharityContact = "Diana Davis",
                Street1 = "12290 Voyager Parkway", 
                City = "Colorado Springs", 
                StateID = "CO", 
                Country = "USA", 
                Zip = "80921",               
                CharityPhone = "800-336-7676",
                CharityEmail = "diana.davis@compassion.com",
                FaithBased = true,
                Website = "www.compassion.com"
            };

            Charity wfp = new Charity
            {
                CharityName = "World Food Program USA",
                CharityContact = "Joe Johnson",
                Street1 = "1725 I Street NW", 
                Street2 = "Suite 510",
                City = "Washington", 
                StateID = "DC", 
                Country="USA", 
                Zip = "20006",
                CharityPhone = "202-627-3737",
                CharityEmail = "joe.johnson@wfpusa.org",
                FaithBased = false,
                Website = "www.wfpusa.org"
            };
            context.Charities.Add(compassion);
            context.Charities.Add(wfp);

            base.Seed(context);
        }


    }
}