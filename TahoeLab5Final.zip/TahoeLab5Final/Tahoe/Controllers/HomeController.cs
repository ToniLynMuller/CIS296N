﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Tahoe.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            DateTime today = DateTime.Today;
            ViewBag.Today = today.ToString("D");
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "About Us";
            return View();
        }

        public ActionResult History()
        {
            ViewBag.Message = "History";
            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Contact Us!";
            return View();
        }
    }
}