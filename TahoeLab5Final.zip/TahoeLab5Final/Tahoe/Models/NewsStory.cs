﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Tahoe.Models
{
    public class NewsStory
    {
        //[Required]
        //[Range(typeof(DateTime), "01/01/2016", "12/31/9999")]
        public DateTime Date { get; set; }
        //[Required]
        //[StringLength(150)]
        public string Title { get; set; }
        //[Required]
        //[StringLength(5000)]
        public string Story { get; set; }
    }
}