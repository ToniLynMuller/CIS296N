﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Tahoe.Models
{
    public class Topic
    {
        List<Message> messages = new List<Message>();
        public int TopicID { get; set; }
        //[Required]
        //[StringLength(150)]
        public string TopicName { get; set; }

        public List<Message> Messages
        {
            get { return messages; }
        }
    }
}