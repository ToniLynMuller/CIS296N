﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Tahoe.Models
{
    public class MessageViewModel
    {
        private Topic topic = new Topic();
        private Member member = new Member();

        public int MessageID { get; set; }

        [Display(Name = "Message Date")]
        [CurrentDate(ErrorMessage = "Message date must be no more than a year from today.")]
        [Required]
        public DateTime MessageDate { get; set; }

        [Display(Name="Member")]
        public Member MemberItem { get { return member; } set { member = value; } }

        [Required]
        [StringLength(100, ErrorMessage = "Please limit your Subject to 100 characters.")]
        public string Subject { get; set; }

        [Required]
        [StringLength(2500, ErrorMessage = "Please limit your Message to 2500 characters.")]
        public string Body { get; set; }

        [Display(Name="Topic")]
        public Topic TopicItem { get { return topic; } set { topic = value; } }
        
    }
}