﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Tahoe.Models
{
    public class Member
    {
        public int MemberID { get; set; }
        [Required]
        [RegularExpression(@"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}", ErrorMessage="Please provide a valid Email address.")]
        public string Email { get; set; }
        [Required]
        [StringLength(100)]
        public string Name { get; set; }
        [Required]
        [RegularExpression(@"(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,16}$", ErrorMessage="Password must be between 8 and 16 characters, contain one uppercase letter, one lowercase letter and a number.")]
        public string Password { get; set; }
    }
}