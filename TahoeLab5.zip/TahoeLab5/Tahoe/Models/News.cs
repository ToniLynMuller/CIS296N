﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Tahoe.Models
{
    public class News
    {
        List<NewsStory> news = new List<NewsStory>();

        public List<NewsStory> NewsStories
        {
            get { return news; }
        }

    }
}