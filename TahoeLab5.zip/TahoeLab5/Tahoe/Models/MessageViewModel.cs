﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Tahoe.Models
{
    public class MessageViewModel
    {
        private Topic topic = new Topic();
        private Member member = new Member();

        public int MessageID { get; set; }
        public DateTime MessageDate { get; set; }
        public Member MemberItem { get { return member; } set { member = value; } }
        public string Subject { get; set; }
        public string Body { get; set; }
        public Topic TopicItem { get { return topic; } set { topic = value; } }
        
    }
}