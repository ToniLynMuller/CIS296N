﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Tahoe.Models
{
    public class Message
    {
        public int MessageID { get; set; }
        public int TopicID { get; set; }
        [Required]
        [Range (typeof(DateTime), "01/01/2016", "12/31/9999")]
        public DateTime MessageDate { get; set; }
        public int MemberID { get; set; }
        [Required]
        [StringLength(150)]
        public string Subject { get; set; }
        [Required]
        [StringLength(5000)]
        public string Body { get; set; }
    }
}