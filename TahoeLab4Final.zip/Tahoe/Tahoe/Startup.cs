﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Tahoe.Startup))]
namespace Tahoe
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
