﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Tahoe.Models
{
    public class Message
    {
        public int MessageID { get; set; }
        public int TopicID { get; set; }
        public DateTime MessageDate { get; set; }
        public int MemberID { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
    }
}