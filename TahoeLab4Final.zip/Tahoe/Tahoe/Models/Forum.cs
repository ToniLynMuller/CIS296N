﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Tahoe.Models
{
    public class Forum
    {
        List<Topic> topics = new List<Topic>();
        public int ForumID { get; set; }
        public string ForumName { get; set; }

        public List<Topic> Topics
        {
            get { return topics; }
        }

    }
}