﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Tahoe.Models
{
    public class Topic
    {
        List<Message> messages = new List<Message>();
        public int TopicID { get; set; }
        public string TopicName { get; set; }

        public List<Message> Messages
        {
            get { return messages; }
        }
    }
}