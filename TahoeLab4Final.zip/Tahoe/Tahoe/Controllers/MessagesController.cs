﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Tahoe.Models;

namespace Tahoe.Controllers
{
    public class MessagesController : Controller
    {
        private TahoeContext db = new TahoeContext();

        // GET: Messages
        public ActionResult Index()
        {
            return View(GetMessagesAuthorsTopics(0));
        }

        // GET: Messages/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            MessageViewModel message = GetMessageDetails(id);
            if (message == null)
            {
                return HttpNotFound();
            }
            return View(message);
        }

        // GET: Messages/Create
        public ActionResult Create()
        {
            ViewBag.TopicNames = new SelectList(db.Topics.OrderBy(t => t.TopicName), "TopicID", "TopicName");
            ViewBag.MemNames = new SelectList(db.Members.OrderBy(m => m.Name), "MemberID", "Name");
            return View();
        }

        // POST: Messages/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "MessageID, MessageDate, MemberItem, Subject, Body, TopicItem, TopicNames, MemNames")] MessageViewModel messVM, int topicNames, int memNames)
        {
            if (ModelState.IsValid)
            {
                Topic topic = (from t in db.Topics
                               where t.TopicID == topicNames
                               select t).FirstOrDefault();

                Member member = (from m in db.Members
                                 where m.MemberID == memNames
                                 select m).FirstOrDefault();

                Message message = new Message() 
                { 
                    //MessageID = messVM.MessageID,
                    MessageDate = messVM.MessageDate,
                    MemberID = member.MemberID,
                    Subject = messVM.Subject,
                    Body = messVM.Body,
                    TopicID = topic.TopicID
                };


                db.Messages.Add(message);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(messVM);
        }

        // GET: Messages/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            MessageViewModel messVM = GetMessageDetails(id);
            if (messVM == null)
            {
                return HttpNotFound();
            }

            ViewBag.TopicNames = new SelectList(db.Topics.OrderBy(t => t.TopicName), "TopicID", "TopicName", messVM.TopicItem.TopicID);
            ViewBag.MemNames = new SelectList(db.Members.OrderBy(m => m.Name), "MemberID", "Name", messVM.MemberItem.MemberID);
            return View(messVM);
        }

        // POST: Messages/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "MessageID,MessageDate,MemberItem,Subject,Body,TopicItem, TopicNames, MemNames")] MessageViewModel messVM, int topicNames, int memNames)
        {
           if (ModelState.IsValid)
           {
               //get message from database using messVM ID
               var message = (from m in db.Messages
                                 where m.MessageID == messVM.MessageID
                                 select m).FirstOrDefault();
               
               //set changes from MessVM
               message.MessageDate = messVM.MessageDate;
               message.MemberID = memNames;
               message.Subject = messVM.Subject;
               message.Body = messVM.Body;
               message.TopicID = topicNames;
               
               db.Entry(message).State = EntityState.Modified;
               db.SaveChanges();
               return RedirectToAction("Index");
           }
           return View(messVM);
        }

        // GET: Messages/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            MessageViewModel messVM = GetMessageDetails(id);
            //Message message = db.Messages.Find(id);
            if (messVM == null)
            {
                return HttpNotFound();
            }
            return View(messVM);
        }

        // POST: Messages/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Message message = db.Messages.Find(id);
            db.Messages.Remove(message);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        public ActionResult Search()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Search(string searchTerm)
        { 
            //get a list Message view models
            List<MessageViewModel> messVMs = new List<MessageViewModel>();
            //get messages that match the search term in the Subject
            List<Message> messages = (from m in db.Messages
                                      where m.Subject.Contains(searchTerm)
                                      select m).ToList();
            foreach (Message m in messages)
            {
                //Get the topic for the message
                var topic = (from t in db.Topics
                             where t.TopicID == m.TopicID
                             select t).FirstOrDefault();

                //Get the member who authored the message
                var member = (from mem in db.Members
                              where mem.MemberID == m.MemberID
                              select mem).FirstOrDefault();

                //Create a Message view model for the message and add to messVMs list
                messVMs.Add(new MessageViewModel()
                {   MessageID = m.MessageID,
                    MessageDate = m.MessageDate,
                    MemberItem = member,
                    Subject = m.Subject,
                    Body = m.Body,
                    TopicItem = topic
                });
            }

            //if one message, display using adapted Detail view
            if (messVMs.Count == 1)
                return View("SearchResultOne", messVMs[0]);
            else
                return View("SearchResultMany", messVMs);
            //if more than one, display using 
        }


        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        //pass 0 for all messages or messageID for one message
        private List<MessageViewModel> GetMessagesAuthorsTopics(int? messageID)
        {
            List<MessageViewModel> messVMs = new List<MessageViewModel>();
            messVMs = (from message in db.Messages
                        join topic in db.Topics on message.TopicID equals topic.TopicID
                        join member in db.Members on message.MemberID equals member.MemberID
                        select new MessageViewModel
                        {
                            MessageID = message.MessageID,
                            MessageDate = message.MessageDate,
                            MemberItem = member,
                            Subject = message.Subject,
                            Body = message.Body,
                            TopicItem = topic
                        }).ToList();
            return messVMs;
        }

        private MessageViewModel GetMessageDetails(int? messageID)
        {
            MessageViewModel messVM = (from message in db.Messages
                                       join topic in db.Topics on message.TopicID equals topic.TopicID
                                       join member in db.Members on message.MemberID equals member.MemberID
                                       where message.MessageID == messageID
                                       select new MessageViewModel
                                       {
                                           MessageID = message.MessageID,
                                           MessageDate = message.MessageDate,
                                           MemberItem = member,
                                           Subject = message.Subject,
                                           Body = message.Body,
                                           TopicItem = topic
                                       }).FirstOrDefault();
            return messVM;
        }
    }
}
