﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace Tahoe.Models
{
    public class TahoeDBInitializer : DropCreateDatabaseIfModelChanges<TahoeContext>
    {
        protected override void Seed(TahoeContext context)
        {
            //create members
            Member member1 = new Member { Name = "Toni Muller", Password = "GuessIt", Email = "tm@gmail.com" };
            Member member2 = new Member { Name = "Lori Campbell", Password = "LizzieBop", Email = "lc@gmail.com" };

            //create topics
            Topic topic1 = new Topic { TopicName = "Skiing" };
            Topic topic2 = new Topic { TopicName = "Hiking" };

            //create messages
            DateTime date1 = new DateTime(2016, 1, 25, 0, 0, 0);
            Message message1 = new Message 
            { 
                MessageDate = date1, 
                MemberID = 1, 
                Subject = "Ski Rentals", 
                Body="I know we can rent gear at the resorts, but are there places in town with better deals?" 
            };
            DateTime date2 = new DateTime(2016, 1, 25, 0, 0, 0);
            Message message2 = new Message
            {
                MessageDate = date2,
                MemberID = 2,
                Subject = "Beginner Resort",
                Body = "Which is the best resort for beginner skiiers?"
            };
            DateTime date3 = new DateTime(2016, 1, 24, 0, 0, 0);
            Message message3 = new Message
            {
                MessageDate = date3,
                MemberID = 1,
                Subject = "Freel Peak",
                Body = "Made it to the top yesterday! Now a day of rest."
            };
            DateTime date4 = new DateTime(2016, 1, 24, 0, 0, 0);
            Message message4 = new Message
            {
                MessageDate = date4,
                MemberID = 2,
                Subject = "Kids Hikes",
                Body = "Can anyone recommend a hike for children 5-8? Thanks!"
            };

            //add items to context
            context.Members.Add(member1);
            context.Members.Add(member2);
            topic1.Messages.Add(message1);
            topic1.Messages.Add(message2);
            topic2.Messages.Add(message3);
            topic2.Messages.Add(message4);
            context.Topics.Add(topic1);
            context.Topics.Add(topic2);

            base.Seed(context);
        }
    }
}