﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Tahoe.Models
{
    public class NewsStory
    {
        public DateTime Date { get; set; }
        public string Title { get; set; }
        public string Story { get; set; }
    }
}