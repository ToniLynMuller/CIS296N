﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Tahoe.Models;

namespace Tahoe.Controllers
{
    public class NewsController : Controller
    {
        News news = new News();

        public NewsController()
        { 
            //create first story
            DateTime date1 = new DateTime(2016, 1, 15, 0, 0, 0);
            NewsStory story1 = new NewsStory
            {
                Date = date1,
                Story = "In its capacity as the Tahoe Metropolitan Planning Organization, the Tahoe Regional Planning Agency this week released a draft active transportation plan for public review and comment.",
                Title = "Comments sought on Tahoe transportation plan"
            };
            //create second story
            DateTime date2 = new DateTime(2016, 1, 15, 0, 0, 0);
            NewsStory story2 = new NewsStory
            {
                Date = date2,
                Story = "An off duty ski school instructor at Sugar Bowl Mountain Resort has been missing for nearly 24 hours.",
                Title = "Ski instructor missing at Sugar Bowl"
            };
            //create third story
            DateTime date3 = new DateTime(2016, 1, 15, 0, 0, 0);
            NewsStory story3 = new NewsStory
            {
                Date = date3,
                Story = "The names of iconic hotels and other landmarks in the world-famous Yosemite National Park will soon change in an ongoing battle over who owns the intellectual property, park officials said Thursday.",
                Title = "Yosemite: Famed hotel name to change"
            };
            //create fourth story
            DateTime date4 = new DateTime(2016, 1, 10, 0, 0, 0);
            NewsStory story4 = new NewsStory
            {
                Date = date4,
                Story = "The median price for a home in the high-end Lake Tahoe market climbed modestly in 2015, according to Nevada-based Chase International Real Estate.",
                Title = "Tahoe real estate market sees gains in 2015"
            };
            //add stories to news
            news.NewsStories.Add(story1);
            news.NewsStories.Add(story2);
            news.NewsStories.Add(story3);
            news.NewsStories.Add(story4);
        }

        // GET: News
        public ActionResult AllNews()
        {
            List<NewsStory> allStories = news.NewsStories;
            return View(allStories);
        }

        public ActionResult Today()
        {
            ViewBag.Message = "Today's News.";
            return View();
        }

        public ActionResult Archive()
        {
            ViewBag.Message = "News Archive";
            return View();
        }
    }
}